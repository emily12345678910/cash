#include <cs50.h>
#include <stdio.h>
#include <math.h>

int main(void)
{
    // promp for change owed
    float d;
    do
    {
        // d for dollar
        d = get_float("Change Owed: ");
    }
    while (d < 0);

    // convert dollar to cents (c for cents)
    float c = round(d * 100);

    // count coins
    int coins = 0;

    // subtract change until paid
    while (c >= 25)
    {
        c = c - 25;
        coins++;
    }

    while (c >= 10)
    {
        c = c - 10;
        coins++;
    }

    while (c >= 5)
    {
        c = c - 5;
        coins++;
    }

    while (c >= 1 && c > 0)
    {
        c = c - 1;
        coins++;
    }

    // print number of coins
    printf("%i\n", coins);
}